"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Trophy, Star, Zap, Target, Brain, Shield, Wind, CloudLightning as Lightning } from "lucide-react"

type PowerType = "speed" | "jump" | "shield" | "teleport"

interface PowerUp {
  type: PowerType
  name: string
  cost: number
  effect: string
  icon: React.ReactNode
  color: string
}

interface GameState {
  playerPosition: { x: number; y: number }
  powerPoints: number
  level: number
  gameActive: boolean
  gameOver: boolean
  gameWon: boolean
  obstacles: Array<{ x: number; y: number; type: string }>
  collectibles: Array<{ x: number; y: number; value: number }>
  destination: { x: number; y: number }
  usedPowers: PowerType[]
  jumpCharges: number
  shieldCharges: number
}

interface FloatingEffect {
  id: number
  x: number
  y: number
  text: string
  color: string
  velocity: { x: number; y: number }
}

const POWER_UPS: PowerUp[] = [
  {
    type: "speed",
    name: "Speed Boost",
    cost: 15,
    effect: "Move 2 spaces forward",
    icon: <Wind className="h-5 w-5" />,
    color: "bg-emerald-600",
  },
  {
    type: "jump",
    name: "Super Jump",
    cost: 20,
    effect: "Jump over obstacles",
    icon: <Zap className="h-5 w-5" />,
    color: "bg-cyan-600",
  },
  {
    type: "shield",
    name: "Energy Shield",
    cost: 25,
    effect: "Protect from damage",
    icon: <Shield className="h-5 w-5" />,
    color: "bg-rose-600",
  },
  {
    type: "teleport",
    name: "Teleport",
    cost: 30,
    effect: "Teleport up to 4 tiles in one direction",
    icon: <Lightning className="h-5 w-5" />,
    color: "bg-amber-600",
  },
]

const LEVELS = [
  {
    name: "Cursed Forest",
    startPower: 80,
    gridSize: 10,
    obstacles: 15,
    collectibles: 2,
    requiredCalculation: "45 × 3 - 67 + 22",
  },
  {
    name: "Volcanic Wasteland",
    startPower: 100,
    gridSize: 12,
    obstacles: 25,
    collectibles: 3,
    requiredCalculation: "144 ÷ 12 + 89 × 2 - 45",
  },
  {
    name: "Shadow Realm",
    startPower: 120,
    gridSize: 14,
    obstacles: 35,
    collectibles: 4,
    requiredCalculation: "256 ÷ 8 + 127 - 49 × 2",
  },
  {
    name: "Nightmare Dimension",
    startPower: 140,
    gridSize: 16,
    obstacles: 50,
    collectibles: 5,
    requiredCalculation: "789 - 234 + 156 ÷ 12 × 7",
  },
]

export default function AdventureGame() {
  const [gameState, setGameState] = useState<GameState>({
    playerPosition: { x: 0, y: 0 },
    powerPoints: 80,
    level: 1,
    gameActive: false,
    gameOver: false,
    gameWon: false,
    obstacles: [],
    collectibles: [],
    destination: { x: 9, y: 9 },
    usedPowers: [],
    jumpCharges: 0,
    shieldCharges: 0,
  })

  const [problem, setProblem] = useState<{ text: string; answer: number } | null>(null)
  const [selectedPower, setSelectedPower] = useState<PowerType | null>(null)
  const [floatingEffects, setFloatingEffects] = useState<FloatingEffect[]>([])
  const [showCalculation, setShowCalculation] = useState(false)
  const [calculationAnswer, setCalculationAnswer] = useState("")
  const [calculationCorrect, setCalculationCorrect] = useState<boolean | null>(null)

  const generateSimpleProblem = (levelNum: number): { text: string; answer: number } => {
    const rand = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min
    const choose = <T,>(a: T[]) => a[Math.floor(Math.random() * a.length)]

    if (levelNum === 1) {
      // 2 terms: + or -
      const a = rand(5, 30)
      const b = rand(5, 30)
      if (Math.random() < 0.5) {
        return { text: `${a} + ${b}`, answer: a + b }
      } else {
        const [x, y] = a >= b ? [a, b] : [b, a]
        return { text: `${x} - ${y}`, answer: x - y }
      }
    }

    if (levelNum === 2) {
      // 2-3 terms, include small *
      const ops = ["+", "-", "*"] as const
      const a = rand(6, 40)
      const b = rand(3, 9)
      const c = rand(3, 20)
      const op1 = choose([...ops])
      const op2 = choose(["+", "-"] as const)
      // keep it simple and small
      const text = `${a} ${op1} ${b} ${op2} ${c}`
      // evaluate safely
      const eval1 = op1 === "+" ? a + b : op1 === "-" ? a - b : a * b
      const ans = op2 === "+" ? eval1 + c : eval1 - c
      return { text, answer: ans }
    }

    if (levelNum === 3) {
      // 3 terms, include small ÷ with exact division
      const a = rand(4, 9)
      const b = rand(3, 9)
      const mul = a * b // divisible
      const c = rand(6, 25)
      const text = `${mul} ÷ ${a} + ${c}`
      const answer = b + c
      return { text, answer }
    }

    // level 4+: 3-4 terms, mixed but still simple
    const a = rand(8, 20)
    const b = rand(2, 9)
    const c = rand(5, 20)
    const d = rand(2, 9)
    // (a*b) ÷ d + c, guarantee divisibility by making numerator multiple of d
    const numerator = a * b * d
    const text = `${numerator} ÷ ${d} + ${c}`
    const answer = a * b + c
    return { text, answer }
  }

  const generateLevel = (levelNum: number) => {
    const level = LEVELS[levelNum - 1]
    const obstacles: Array<{ x: number; y: number; type: string }> = []
    const collectibles: Array<{ x: number; y: number; value: number }> = []

    const okToPlace = (x: number, y: number) => {
      const gs = level.gridSize
      // keep cells around start/destination more open
      const nearStart = x <= 1 && y <= 1
      const nearDest = x >= gs - 2 && y >= gs - 2
      if (nearStart || nearDest) return false
      // avoid 2x2 blocks
      const has = (px: number, py: number) => obstacles.some((o) => o.x === px && o.y === py)
      const makesBlock = has(x - 1, y) && has(x, y - 1) && has(x - 1, y - 1)
      return !makesBlock
    }

    for (let i = 0; i < level.obstacles; i++) {
      let x,
        y,
        tries = 0
      do {
        x = Math.floor(Math.random() * level.gridSize)
        y = Math.floor(Math.random() * level.gridSize)
        tries++
      } while (
        tries < 200 &&
        ((x === 0 && y === 0) ||
          (x === level.gridSize - 1 && y === level.gridSize - 1) ||
          obstacles.some((obs) => obs.x === x && obs.y === y) ||
          !okToPlace(x, y))
      )
      if (
        !obstacles.some((obs) => obs.x === x && obs.y === y) &&
        !(x === 0 && y === 0) &&
        !(x === level.gridSize - 1 && y === level.gridSize - 1)
      ) {
        obstacles.push({ x, y, type: "rock" })
      }
    }

    // Generate collectibles
    for (let i = 0; i < level.collectibles; i++) {
      let x, y
      do {
        x = Math.floor(Math.random() * level.gridSize)
        y = Math.floor(Math.random() * level.gridSize)
      } while (
        (x === 0 && y === 0) ||
        (x === level.gridSize - 1 && y === level.gridSize - 1) ||
        obstacles.some((obs) => obs.x === x && obs.y === y)
      )

      collectibles.push({ x, y, value: Math.floor(Math.random() * 20) + 10 })
    }

    return {
      obstacles,
      collectibles,
      destination: { x: level.gridSize - 1, y: level.gridSize - 1 },
      gridSize: level.gridSize,
    }
  }

  const startGame = () => {
    const levelData = generateLevel(gameState.level)
    const p = generateSimpleProblem(gameState.level)
    setProblem(p)
    setGameState({
      playerPosition: { x: 0, y: 0 },
      powerPoints: LEVELS[gameState.level - 1].startPower,
      level: gameState.level,
      gameActive: true,
      gameOver: false,
      gameWon: false,
      obstacles: levelData.obstacles,
      collectibles: levelData.collectibles,
      destination: levelData.destination,
      usedPowers: [],
      // reset ephemeral charges
      jumpCharges: 0,
      shieldCharges: 0,
    })
    setShowCalculation(true)
  }

  const checkCalculation = () => {
    if (!problem) return
    const isCorrect = Number.parseInt(calculationAnswer) === problem.answer
    setCalculationCorrect(isCorrect)

    if (isCorrect) {
      setShowCalculation(false)
      addFloatingEffect("Calculation Correct! +20 Power!", "text-emerald-400")
      setGameState((prev) => ({ ...prev, powerPoints: prev.powerPoints + 20 }))
    } else {
      setTimeout(() => setCalculationCorrect(null), 2000)
    }
  }

  const addFloatingEffect = (text: string, color: string) => {
    const effect: FloatingEffect = {
      id: Date.now(),
      x: Math.random() * 80 + 10,
      y: Math.random() * 60 + 20,
      text,
      color,
      velocity: { x: (Math.random() - 0.5) * 2, y: -2 },
    }
    setFloatingEffects((prev) => [...prev, effect])
    setTimeout(() => {
      setFloatingEffects((prev) => prev.filter((e) => e.id !== effect.id))
    }, 3000)
  }

  const activatePower = (powerType: PowerType) => {
    const power = POWER_UPS.find((p) => p.type === powerType)
    if (!power || gameState.powerPoints < power.cost) return

    setGameState((prev) => ({
      ...prev,
      powerPoints: prev.powerPoints - power.cost,
      usedPowers: [...prev.usedPowers, powerType],
      ...(powerType === "jump" ? { jumpCharges: prev.jumpCharges + 1 } : {}),
      ...(powerType === "shield" ? { shieldCharges: prev.shieldCharges + 1 } : {}),
    }))

    addFloatingEffect(`-${power.cost} Power`, "text-red-500")

    switch (powerType) {
      case "speed":
        movePlayer(2, 0)
        break
      case "jump":
        addFloatingEffect("Jump ready for next obstacle!", "text-blue-500")
        break
      case "shield":
        addFloatingEffect("Shield ready for next obstacle!", "text-purple-500")
        break
      case "teleport":
        setSelectedPower("teleport")
        addFloatingEffect(
          "Teleport ready! Use arrows/WASD or Q,E,Z,C for diagonals, or click a highlighted tile (up to 4).",
          "text-amber-400",
        )
        break
    }
  }

  const getTeleportTargets = (): Array<{ x: number; y: number }> => {
    if (selectedPower !== "teleport") return []
    const level = LEVELS[gameState.level - 1]
    const { x, y } = gameState.playerPosition
    const dirs = [
      { dx: 0, dy: -1 }, // up
      { dx: 0, dy: 1 }, // down
      { dx: -1, dy: 0 }, // left
      { dx: 1, dy: 0 }, // right
      { dx: -1, dy: -1 }, // up-left
      { dx: 1, dy: -1 }, // up-right
      { dx: -1, dy: 1 }, // down-left
      { dx: 1, dy: 1 }, // down-right
    ]
    const targets: Array<{ x: number; y: number }> = []
    for (const { dx, dy } of dirs) {
      for (let step = 1; step <= 4; step++) {
        const nx = x + dx * step
        const ny = y + dy * step
        if (nx < 0 || ny < 0 || nx >= level.gridSize || ny >= level.gridSize) break
        const blocked = gameState.obstacles.some((obs) => obs.x === nx && obs.y === ny)
        if (blocked) break
        targets.push({ x: nx, y: ny })
      }
    }
    return targets
  }

  const teleportTo = (tx: number, ty: number) => {
    const { x, y } = gameState.playerPosition
    if (tx === x && ty === y) {
      addFloatingEffect("No valid teleport path!", "text-rose-400")
      setSelectedPower(null)
      return
    }

    const found = gameState.collectibles.find((c) => c.x === tx && c.y === ty)
    const gained = found?.value ?? 0

    setGameState((prev) => {
      const atDest = tx === prev.destination.x && ty === prev.destination.y
      const newCollectibles = prev.collectibles.filter((c) => !(c.x === tx && c.y === ty))
      return {
        ...prev,
        playerPosition: { x: tx, y: ty },
        collectibles: newCollectibles,
        powerPoints: prev.powerPoints + gained,
        ...(atDest ? { gameWon: true, gameActive: false } : {}),
      }
    })
    addFloatingEffect("Teleported!", "text-orange-500")
    if (gained > 0) addFloatingEffect(`+${gained} Power!`, "text-emerald-400")
    setSelectedPower(null)
  }

  const movePlayer = (deltaX: number, deltaY: number) => {
    const level = LEVELS[gameState.level - 1]
    const curX = gameState.playerPosition.x
    const curY = gameState.playerPosition.y
    const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v))

    // first intended landing
    let newX = clamp(curX + deltaX, 0, level.gridSize - 1)
    let newY = clamp(curY + deltaY, 0, level.gridSize - 1)

    const dirX = Math.sign(deltaX)
    const dirY = Math.sign(deltaY)

    const isObstacle = (x: number, y: number) => gameState.obstacles.some((o) => o.x === x && o.y === y)

    let blocked = isObstacle(newX, newY)
    let usedJump = false
    let usedShield = false

    if (blocked) {
      // try jump over
      if (gameState.jumpCharges > 0) {
        const beyondX = clamp(newX + dirX, 0, level.gridSize - 1)
        const beyondY = clamp(newY + dirY, 0, level.gridSize - 1)
        if (!(beyondX === newX && beyondY === newY) && !isObstacle(beyondX, beyondY)) {
          newX = beyondX
          newY = beyondY
          blocked = false
          usedJump = true
        }
      }

      // if still blocked, try shield to pass into obstacle tile
      if (blocked && gameState.shieldCharges > 0) {
        blocked = false
        usedShield = true
      }
    }

    if (blocked) {
      addFloatingEffect("Blocked by obstacle!", "text-rose-400")
      return
    }

    // apply movement
    setGameState((prev) => {
      const next = { ...prev }

      // consume charges
      if (usedJump && next.jumpCharges > 0) next.jumpCharges -= 1
      if (usedShield && next.shieldCharges > 0) next.shieldCharges -= 1

      next.playerPosition = { x: newX, y: newY }

      // collectibles
      const collectible = next.collectibles.find((col) => col.x === newX && col.y === newY)
      if (collectible) {
        next.powerPoints = next.powerPoints + collectible.value
        next.collectibles = next.collectibles.filter((col) => col.x !== newX || col.y !== newY)
      }

      // destination
      if (newX === next.destination.x && newY === next.destination.y) {
        next.gameWon = true
        next.gameActive = false
      }

      // movement cost
      const newPP = next.powerPoints - 8
      if (newPP <= 0) {
        next.powerPoints = 0
        next.gameOver = true
        next.gameActive = false
      } else {
        next.powerPoints = newPP
      }

      return next
    })

    if (usedJump) addFloatingEffect("Jumped over obstacle!", "text-blue-500")
    if (usedShield) addFloatingEffect("Shield protected you!", "text-purple-500")
  }

  const handleGridClick = (x: number, y: number) => {
    if (selectedPower === "teleport") {
      const targets = getTeleportTargets()
      const isTarget = targets.some((t) => t.x === x && t.y === y)
      if (isTarget) {
        teleportTo(x, y)
      } else {
        addFloatingEffect("Pick a highlighted tile (up to 4 in any direction).", "text-amber-400")
      }
      return
    }
    // ignore other clicks
  }

  const nextLevel = () => {
    if (gameState.level < LEVELS.length) {
      setGameState((prev) => ({ ...prev, level: prev.level + 1, gameWon: false }))
    }
  }

  const resetGame = () => {
    setGameState({
      playerPosition: { x: 0, y: 0 },
      powerPoints: 80,
      level: 1,
      gameActive: false,
      gameOver: false,
      gameWon: false,
      obstacles: [],
      collectibles: [],
      destination: { x: 9, y: 9 },
      usedPowers: [],
      jumpCharges: 0,
      shieldCharges: 0,
    })
    setCalculationAnswer("")
    setCalculationCorrect(null)
    setShowCalculation(false)
  }

  const teleportInDirection = (dx: number, dy: number) => {
    const level = LEVELS[gameState.level - 1]
    const { x, y } = gameState.playerPosition

    let targetX = x
    let targetY = y

    for (let step = 1; step <= 4; step++) {
      const nx = x + dx * step
      const ny = y + dy * step

      // bounds check
      if (nx < 0 || ny < 0 || nx >= level.gridSize || ny >= level.gridSize) break

      // stop before obstacle
      const blocked = gameState.obstacles.some((obs) => obs.x === nx && obs.y === ny)
      if (blocked) break

      targetX = nx
      targetY = ny
    }

    if (targetX === x && targetY === y) {
      addFloatingEffect("No valid teleport path!", "text-rose-400")
      setSelectedPower(null)
      return
    }

    // pre-calc collectible (for feedback text), then update state once
    const found = gameState.collectibles.find((c) => c.x === targetX && c.y === targetY)
    const gained = found?.value ?? 0

    setGameState((prev) => {
      const atDest = targetX === prev.destination.x && targetY === prev.destination.y
      const newCollectibles = prev.collectibles.filter((c) => !(c.x === targetX && c.y === targetY))

      return {
        ...prev,
        playerPosition: { x: targetX, y: targetY },
        collectibles: newCollectibles,
        powerPoints: prev.powerPoints + gained, // teleport doesn't consume movement cost, only its activation cost
        ...(atDest ? { gameWon: true, gameActive: false } : {}),
      }
    })

    addFloatingEffect("Teleported!", "text-orange-500")
    if (gained > 0) addFloatingEffect(`+${gained} Power!`, "text-emerald-400")
    setSelectedPower(null)
  }

  const currentLevel = LEVELS[gameState.level - 1]
  const gridSize = currentLevel?.gridSize || 10

  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (!gameState.gameActive || showCalculation) return

      const key = event.key.toLowerCase()

      const teleportArmed = selectedPower === "teleport"
      if (teleportArmed) {
        switch (key) {
          case "w":
          case "arrowup":
            event.preventDefault()
            teleportInDirection(0, -1)
            return
          case "s":
          case "arrowdown":
            event.preventDefault()
            teleportInDirection(0, 1)
            return
          case "a":
          case "arrowleft":
            event.preventDefault()
            teleportInDirection(-1, 0)
            return
          case "d":
          case "arrowright":
            event.preventDefault()
            teleportInDirection(1, 0)
            return
          // diagonals
          case "q": // up-left
            event.preventDefault()
            teleportInDirection(-1, -1)
            return
          case "e": // up-right
            event.preventDefault()
            teleportInDirection(1, -1)
            return
          case "z": // down-left
            event.preventDefault()
            teleportInDirection(-1, 1)
            return
          case "c": // down-right
            event.preventDefault()
            teleportInDirection(1, 1)
            return
          default:
            // ignore other keys while teleport is armed
            break
        }
      }

      // Movement controls (WASD or Arrow keys)
      switch (key) {
        case "w":
        case "arrowup":
          event.preventDefault()
          movePlayer(0, -1)
          break
        case "s":
        case "arrowdown":
          event.preventDefault()
          movePlayer(0, 1)
          break
        case "a":
        case "arrowleft":
          event.preventDefault()
          movePlayer(-1, 0)
          break
        case "d":
        case "arrowright":
          event.preventDefault()
          movePlayer(1, 0)
          break

        // Power-up controls (1-4 keys)
        case "1":
          event.preventDefault()
          activatePower("speed")
          break
        case "2":
          event.preventDefault()
          activatePower("jump")
          break
        case "3":
          event.preventDefault()
          activatePower("shield")
          break
        case "4":
          event.preventDefault()
          activatePower("teleport")
          break

        // Game controls
        case "r":
          if (gameState.gameOver || gameState.gameWon) {
            event.preventDefault()
            resetGame()
          }
          break
        case "n":
          if (gameState.gameWon && gameState.level < LEVELS.length) {
            event.preventDefault()
            nextLevel()
          }
          break
        case "enter":
          if (!gameState.gameActive && !gameState.gameOver && !gameState.gameWon) {
            event.preventDefault()
            startGame()
          }
          break
      }
    }

    const handleCalculationKeyPress = (event: KeyboardEvent) => {
      if (!showCalculation) return

      if (event.key === "Enter" && calculationAnswer) {
        event.preventDefault()
        checkCalculation()
      }
    }

    window.addEventListener("keydown", handleKeyPress)
    window.addEventListener("keydown", handleCalculationKeyPress)

    return () => {
      window.removeEventListener("keydown", handleKeyPress)
      window.removeEventListener("keydown", handleCalculationKeyPress)
    }
  }, [gameState, showCalculation, calculationAnswer, selectedPower])

  useEffect(() => {
    const stop = (e: Event) => {
      const el = e.target as HTMLElement | null
      if (el && (el.closest("button") || el.closest("input"))) {
        return
      }
      // Allow teleport target clicks
      if (selectedPower === "teleport" && el && el.closest("[data-teleport-target]")) {
        return
      }
      // Block all other pointer events on the grid during gameplay
      if (gameState.gameActive && !showCalculation && el && el.closest("[data-grid-cell]")) {
        e.preventDefault()
        e.stopPropagation()
      }
    }

    window.addEventListener("click", stop, { capture: true })

    return () => {
      window.removeEventListener("click", stop, { capture: true })
    }
  }, [showCalculation, selectedPower, gameState.gameActive])

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 via-teal-900 to-emerald-900 relative overflow-hidden">
      {/* Floating Effects */}
      {floatingEffects.map((effect) => (
        <div
          key={effect.id}
          className={`absolute pointer-events-none select-none ${effect.color} font-bold text-lg animate-bounce z-50`}
          style={{
            left: `${effect.x}%`,
            top: `${effect.y}%`,
            animation: "floatUp 3s ease-out forwards",
          }}
        >
          {effect.text}
        </div>
      ))}

      {/* Background Stars */}
      <div className="absolute inset-0 overflow-hidden">
        {Array.from({ length: 50 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-emerald-300 rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              opacity: Math.random() * 0.8 + 0.2,
            }}
          />
        ))}
      </div>

      <div className="min-h-screen p-4 flex flex-col space-y-4 relative z-10">
        <div className="text-center space-y-1">
          <h1 className="text-4xl font-bold text-white flex items-center justify-center gap-3">
            <Brain className="h-10 w-10 text-amber-400 animate-pulse" />
            Math Adventure Quest
          </h1>
          <p className="text-teal-200 text-lg">Calculate your way to victory!</p>
        </div>

        {/* Game Stats */}
        <div className="grid grid-cols-4 gap-2">
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-3 text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Zap className="h-4 w-4 text-amber-400" />
                <span className="font-semibold text-white text-sm">Power</span>
              </div>
              <p className="text-xl font-bold text-amber-400">{gameState.powerPoints}</p>
            </CardContent>
          </Card>
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-3 text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Target className="h-4 w-4 text-emerald-400" />
                <span className="font-semibold text-white text-sm">Level</span>
              </div>
              <p className="text-xl font-bold text-emerald-400">{gameState.level}</p>
            </CardContent>
          </Card>
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-3 text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Star className="h-4 w-4 text-rose-400" />
                <span className="font-semibold text-white text-sm">Items</span>
              </div>
              <p className="text-xl font-bold text-rose-400">{gameState.collectibles.length}</p>
            </CardContent>
          </Card>
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-3 text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Trophy className="h-4 w-4 text-cyan-400" />
                <span className="font-semibold text-white text-sm">Score</span>
              </div>
              <p className="text-xl font-bold text-cyan-400">{gameState.gameWon ? gameState.powerPoints : 0}</p>
            </CardContent>
          </Card>
        </div>

        {/* Calculation Modal */}
        {showCalculation && (
          <Card className="mx-auto max-w-md bg-white/95 backdrop-blur-sm">
            <CardHeader className="text-center pb-4">
              <CardTitle className="text-2xl">Solve to Start!</CardTitle>
              <CardDescription>Calculate the answer to unlock your powers</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary mb-4">{problem?.text} = ?</div>
                <input
                  data-allow-pointer
                  type="number"
                  value={calculationAnswer}
                  onChange={(e) => setCalculationAnswer(e.target.value)}
                  className="w-full p-3 text-center text-xl border rounded-lg"
                  placeholder="Enter answer..."
                />
              </div>
              <Button data-allow-pointer onClick={checkCalculation} className="w-full" disabled={!calculationAnswer}>
                Check Answer
              </Button>
              {calculationCorrect === false && (
                <div className="text-center text-red-600 font-semibold">Incorrect! Try again.</div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Game Board - Single Row Layout */}
        {gameState.gameActive && !showCalculation && (
          <div className="flex-1 grid grid-cols-3 gap-4">
            {/* Power-ups Panel */}
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader className="pb-2">
                <CardTitle className="text-white text-lg">Power-ups</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {POWER_UPS.map((power, index) => (
                  <div
                    key={power.type}
                    className={`w-full flex items-center gap-2 p-2 rounded-lg transition-all duration-200 ${
                      gameState.powerPoints >= power.cost ? `${power.color}` : "bg-gray-600 opacity-50"
                    }`}
                  >
                    {power.icon}
                    <div className="text-left flex-1">
                      <div className="font-semibold text-white text-sm">{power.name}</div>
                      <div className="text-xs text-white/90">{power.effect}</div>
                    </div>
                    <div className="flex items-center gap-1">
                      <Badge variant="outline" className="text-white border-white/50 text-xs">
                        {index + 1}
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        {power.cost}
                      </Badge>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Game Grid */}
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader className="pb-2">
                <CardTitle className="text-white text-lg">{currentLevel.name}</CardTitle>
                <CardDescription className="text-teal-200 text-sm">
                  Reach the golden destination! Movement costs 8 power.
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-1 flex items-center justify-center">
                <div
                  className="grid gap-1"
                  style={{
                    gridTemplateColumns: `repeat(${gridSize}, minmax(0, 1fr))`,
                    maxWidth: "400px",
                    maxHeight: "400px",
                  }}
                >
                  {(() => {
                    const targets = getTeleportTargets()
                    return Array.from({ length: gridSize * gridSize }).map((_, index) => {
                      const x = index % gridSize
                      const y = Math.floor(index / gridSize)
                      const isPlayer = gameState.playerPosition.x === x && gameState.playerPosition.y === y
                      const isDestination = gameState.destination.x === x && gameState.destination.y === y
                      const hasObstacle = gameState.obstacles.some((obs) => obs.x === x && obs.y === y)
                      const collectible = gameState.collectibles.find((col) => col.x === x && col.y === y)
                      const isTeleportTarget =
                        selectedPower === "teleport" && targets.some((t) => t.x === x && t.y === y)

                      return (
                        <div
                          key={index}
                          onClick={() => handleGridClick(x, y)}
                          data-grid-cell
                          data-teleport-target={isTeleportTarget ? "true" : undefined}
                          className={`
                            aspect-square border border-white/30 rounded transition-all duration-200 flex items-center justify-center text-xs font-bold
                            ${isPlayer ? "bg-cyan-500 animate-pulse" : ""}
                            ${isDestination ? "bg-amber-500 animate-bounce" : ""}
                            ${hasObstacle ? "bg-rose-500" : ""}
                            ${collectible ? "bg-emerald-500 animate-pulse" : ""}
                            ${!isPlayer && !isDestination && !hasObstacle && !collectible ? "bg-white/20" : ""}
                            ${isTeleportTarget ? "ring-2 ring-amber-400 cursor-pointer hover:ring-4" : ""}
                          `}
                        >
                          {isPlayer && "🧙‍♂️"}
                          {isDestination && "🏆"}
                          {hasObstacle && "🪨"}
                          {collectible && `+${collectible.value}`}
                        </div>
                      )
                    })
                  })()}
                </div>
              </CardContent>
            </Card>

            {/* Game Info */}
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardHeader className="pb-2">
                <CardTitle className="text-white text-lg">Game Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center text-white text-sm space-y-2">
                  <p>🪨 Obstacles • 💎 Collectibles • 🏆 Destination</p>
                  <p>Powers: 1-Speed 2-Jump 3-Shield 4-Teleport</p>
                  <p>Used Powers: {gameState.usedPowers.length}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Game Start Screen */}
        {!gameState.gameActive && !gameState.gameOver && !gameState.gameWon && (
          <Card className="mx-auto max-w-2xl bg-white/10 backdrop-blur-sm border-white/20">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl text-white">Ready for Adventure?</CardTitle>
              <CardDescription className="text-teal-200 text-lg">
                Use math skills and strategy to reach your destination!
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center space-y-4">
                <h3 className="text-xl font-bold text-white">
                  Level {gameState.level}: {currentLevel.name}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="bg-white/20 p-3 rounded-lg">
                    <div className="text-amber-400 font-bold">Starting Power</div>
                    <div className="text-white">{currentLevel.startPower}</div>
                  </div>
                  <div className="bg-white/20 p-3 rounded-lg">
                    <div className="text-rose-400 font-bold">Obstacles</div>
                    <div className="text-white">{currentLevel.obstacles}</div>
                  </div>
                  <div className="bg-white/20 p-3 rounded-lg">
                    <div className="text-emerald-400 font-bold">Collectibles</div>
                    <div className="text-white">{currentLevel.collectibles}</div>
                  </div>
                </div>
              </div>
              <Button
                data-allow-pointer
                onClick={startGame}
                size="lg"
                className="w-full bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 text-white font-bold py-3"
              >
                <Star className="mr-2 h-6 w-6" />
                Start Adventure (Press Enter)
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Game Over Screen */}
        {gameState.gameOver && (
          <Card className="mx-auto max-w-2xl bg-rose-900/50 backdrop-blur-sm border-rose-500/50">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl text-rose-400">Game Over!</CardTitle>
              <CardDescription className="text-rose-200">
                You ran out of power before reaching the destination.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <p className="text-white text-lg">Better luck next time!</p>
                <p className="text-rose-200">Try using power-ups more strategically.</p>
              </div>
              <Button data-allow-pointer onClick={resetGame} size="lg" className="w-full bg-rose-600 hover:bg-rose-700">
                Try Again (Press R)
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Victory Screen */}
        {gameState.gameWon && (
          <Card className="mx-auto max-w-2xl bg-emerald-900/50 backdrop-blur-sm border-emerald-500/50">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl text-emerald-400 flex items-center justify-center gap-2">
                <Trophy className="h-8 w-8" />
                Victory!
              </CardTitle>
              <CardDescription className="text-emerald-200">You reached the destination successfully!</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center space-y-2">
                <p className="text-2xl font-bold text-amber-400">Final Score: {gameState.powerPoints} Power Points</p>
                <p className="text-emerald-200">Powers Used: {gameState.usedPowers.length}</p>
              </div>
              <div className="flex gap-2">
                {gameState.level < LEVELS.length ? (
                  <Button
                    data-allow-pointer
                    onClick={nextLevel}
                    size="lg"
                    className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                  >
                    Next Level (Press N)
                  </Button>
                ) : (
                  <Button
                    data-allow-pointer
                    onClick={resetGame}
                    size="lg"
                    className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                  >
                    Play Again (Press R)
                  </Button>
                )}
                <Button
                  data-allow-pointer
                  onClick={resetGame}
                  size="lg"
                  variant="outline"
                  className="flex-1 bg-transparent"
                >
                  Restart (Press R)
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <style jsx>{`
        @keyframes floatUp {
          0% { transform: translateY(0px) scale(1); opacity: 1; }
          100% { transform: translateY(-100px) scale(0.8); opacity: 0; }
        }
      `}</style>
    </div>
  )
}

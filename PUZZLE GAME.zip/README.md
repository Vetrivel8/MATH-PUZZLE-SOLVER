# Math Adventure Quest

A thrilling math puzzle adventure game where you calculate your way to victory! Navigate through challenging levels using strategic power-ups and mathematical problem-solving skills.

## How to Play

### Objective
Guide your wizard character 🧙‍♂️ through obstacle-filled levels to reach the golden destination 🏆 while managing your power points strategically.

### Getting Started
1. **Start the Game**: Press `Enter` or click "Start Adventure"
2. **Solve the Math Problem**: Each level begins with a calculation you must solve correctly to unlock your powers
3. **Navigate to Victory**: Use keyboard controls to move through the grid and reach the destination

### Keyboard Controls

#### Movement
- **W** or **↑** - Move Up
- **A** or **←** - Move Left  
- **S** or **↓** - Move Down
- **D** or **→** - Move Right

#### Power-ups (Press number keys)
- **1** - Speed Boost (15 power) - Move 2 spaces forward
- **2** - Super Jump (20 power) - Jump over obstacles  
- **3** - Energy Shield (25 power) - Protect from obstacle damage
- **4** - Teleport (30 power) - Click any safe space to teleport there

#### Game Controls
- **Enter** - Start game / Confirm calculation answer
- **R** - Restart game / Try again after game over
- **N** - Next level (when available)

### Game Elements

#### Grid Symbols
- 🧙‍♂️ **Player** - Your wizard character
- 🏆 **Destination** - Reach this to complete the level
- 🪨 **Obstacles** - Block movement (unless you have shield/jump)
- 💎 **Collectibles** - Green numbers that give bonus power points

#### Power System
- **Starting Power**: Each level gives you initial power points
- **Movement Cost**: Moving costs 8 power points per step
- **Power-up Costs**: Each power-up has a specific cost
- **Game Over**: Reaching 0 power points before the destination ends the game
- **Final Score**: Remaining power points after reaching the destination

### Levels

#### Level 1: Cursed Forest
- **Math Problem**: 45 × 3 - 67 + 22 = ?
- **Starting Power**: 80 points
- **Grid Size**: 10x10
- **Obstacles**: 15
- **Collectibles**: 2

#### Level 2: Volcanic Wasteland  
- **Math Problem**: 144 ÷ 12 + 89 × 2 - 45 = ?
- **Starting Power**: 100 points
- **Grid Size**: 12x12
- **Obstacles**: 25
- **Collectibles**: 3

#### Level 3: Shadow Realm
- **Math Problem**: 256 ÷ 8 + 127 - 49 × 2 = ?
- **Starting Power**: 120 points
- **Grid Size**: 14x14
- **Obstacles**: 35
- **Collectibles**: 4

#### Level 4: Nightmare Dimension
- **Math Problem**: 789 - 234 + 156 ÷ 12 × 7 = ?
- **Starting Power**: 140 points
- **Grid Size**: 16x16
- **Obstacles**: 50
- **Collectibles**: 5

### Strategy Tips

1. **Calculate Wisely**: Solve the initial math problem correctly to get bonus power points
2. **Plan Your Route**: Study the grid before moving to find the most efficient path
3. **Collect Power-ups**: Green collectibles give you extra power points
4. **Use Powers Strategically**: 
   - Use Speed Boost for long straight paths
   - Use Jump/Shield when facing obstacles
   - Save Teleport for emergency escapes
5. **Manage Resources**: Balance movement costs with power-up usage - every step now costs 8 power!

### Scoring
- Complete levels with remaining power points to achieve high scores
- Collect all power-ups for maximum points
- Use fewer powers for better efficiency ratings

### Installation & Setup

This game runs in your browser using Next.js. To install and run locally:

1. Download the project files
2. Install dependencies: `npm install`
3. Run the development server: `npm run dev`
4. Open `http://localhost:3000` in your browser

### Technical Requirements
- Modern web browser with JavaScript enabled
- Keyboard for optimal gameplay experience
- No additional installations required

---

**Good luck on your mathematical adventure!** 🧙‍♂️✨
